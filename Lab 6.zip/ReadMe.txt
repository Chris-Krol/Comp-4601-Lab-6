Ahmed Ashkir
101088255

Christopher Krol
101010495

COMP 4601 - Lab 6

Installation:
npm install

To use for different files, change the file name that is being inputed on line 4 of the code then just use node main.js to run
